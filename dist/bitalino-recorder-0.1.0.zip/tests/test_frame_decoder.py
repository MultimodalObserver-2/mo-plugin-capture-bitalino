import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from bitalino_recorder.bitalino_frame_decoder import BitalinoFrameDecoder
from bitalino_recorder.bitalino_exception import BitalinoException
from bitalino_recorder.bitalino_frame import BitalinoFrame
from bitalino_recorder.bitalino_error_types import BitalinoErrorTypes


class TestBitalinoFrameDecoderValidCRC(unittest.TestCase):
    def _decode_1ch(self):
        return BitalinoFrameDecoder.decode(bytes([0, 0, 0]), [0], 3)

    def test_returns_frame_object(self):
        frame = self._decode_1ch()
        self.assertIsInstance(frame, BitalinoFrame)

    def test_valid_crc_seq_not_minus_one(self):
        frame = self._decode_1ch()
        self.assertNotEqual(frame.get_seq(), -1)

    def test_valid_crc_seq_is_zero(self):
        frame = self._decode_1ch()
        self.assertEqual(frame.get_seq(), 0)

    def test_valid_crc_analog_ch0_is_zero(self):
        frame = self._decode_1ch()
        self.assertEqual(frame.get_analog(0), 0)

    def test_valid_crc_digital_all_zero(self):
        frame = self._decode_1ch()
        for i in range(4):
            self.assertEqual(frame.get_digital(i), 0)

    def test_two_channels_valid(self):
        frame = BitalinoFrameDecoder.decode(bytes([0, 0, 0, 0]), [0, 1], 4)
        self.assertNotEqual(frame.get_seq(), -1)

    def test_crc_value_stored_matches(self):
        frame = self._decode_1ch()
        self.assertGreaterEqual(frame.get_seq(), 0)


class TestBitalinoFrameDecoderInvalidCRC(unittest.TestCase):
    def test_invalid_crc_seq_is_minus_one(self):
        frame = BitalinoFrameDecoder.decode(bytes([0, 0, 1]), [0], 3)
        self.assertEqual(frame.get_seq(), -1)

    def test_invalid_crc_does_not_raise(self):
        frame = BitalinoFrameDecoder.decode(bytes([0, 0, 1]), [0], 3)
        self.assertIsInstance(frame, BitalinoFrame)

    def test_various_invalid_crc_buffers(self):
        for bad_byte in [1, 2, 3, 5, 7, 15]:
            frame = BitalinoFrameDecoder.decode(bytes([0, 0, bad_byte]), [0], 3)
            self.assertEqual(frame.get_seq(), -1, msg=f"Expected seq=-1 for bad_byte={bad_byte}")


class TestBitalinoFrameDecoderExceptions(unittest.TestCase):
    def test_empty_buffer_raises_bitalino_exception(self):
        with self.assertRaises(BitalinoException):
            BitalinoFrameDecoder.decode(bytes([]), [0], 3)

    def test_too_short_buffer_raises(self):
        with self.assertRaises(BitalinoException):
            BitalinoFrameDecoder.decode(bytes([0]), [0], 3)

    def test_exception_has_correct_code(self):
        try:
            BitalinoFrameDecoder.decode(bytes([]), [0], 3)
            self.fail("Should have raised BitalinoException")
        except BitalinoException as e:
            self.assertEqual(e.code, BitalinoErrorTypes.DECODE_INVALID_DATA.code)


class TestBitalinoException(unittest.TestCase):
    def test_exception_has_description_message(self):
        exc = BitalinoException(BitalinoErrorTypes.LOST_COMMUNICATION)
        self.assertIn("lost communication", str(exc).lower())

    def test_exception_has_code_attribute(self):
        exc = BitalinoException(BitalinoErrorTypes.UNDEFINED)
        self.assertEqual(exc.code, 12)

    def test_exception_inherit(self):
        exc = BitalinoException(BitalinoErrorTypes.BT_DEVICE_NOT_CONNECTED)
        self.assertIsInstance(exc, Exception)

    def test_exception_error_type(self):
        exc = BitalinoException(BitalinoErrorTypes.BT_DEVICE_NOT_CONNECTED)
        self.assertEqual(exc.code, BitalinoErrorTypes.BT_DEVICE_NOT_CONNECTED.code)


if __name__ == '__main__':
    unittest.main()
