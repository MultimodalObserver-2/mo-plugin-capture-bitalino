import sys
import os
import types
import unittest
import importlib.util

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

SRC = os.path.join(os.path.dirname(__file__), '..', 'src', 'bitalino_recorder')


class MockPropertySelectOption:
    def __init__(self, label=None, value=None):
        self.label = label
        self.value = value


class MockProperties:
    def __init__(self):
        self._fields = {}
        self._defaults = {}

    def add_text(self, key, label=None):
        self._fields[key] = {'type': 'text', 'label': label}

    def add_select(self, key, label=None, options=None):
        self._fields[key] = {'type': 'select', 'label': label, 'options': options or []}

    def set_default(self, key, value):
        self._defaults[key] = value


mo_core = types.ModuleType('_bt_props_mo_core')
mo_core.Properties = MockProperties
mo_core.PropertySelectOption = MockPropertySelectOption
mo_core.Settings = object
mo_core.translate = lambda s: s

mo = types.ModuleType('_bt_props_mo')


def load_properties():
    extra = {'mo': mo, 'mo.core': mo_core}
    for k, v in extra.items():
        sys.modules[k] = v
    spec = importlib.util.spec_from_file_location(
        '_bt_props_mod', os.path.join(SRC, 'properties.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


props_mod = load_properties()


class TestGetSamplingRateOptions(unittest.TestCase):
    def test_returns_two_options(self):
        opts = props_mod.get_sampling_rate_options()
        self.assertEqual(len(opts), 2)

    def test_100hz_option_label(self):
        opts = props_mod.get_sampling_rate_options()
        labels = [o.label for o in opts]
        self.assertIn("100 Hz", labels)

    def test_1000hz_option_value(self):
        opts = props_mod.get_sampling_rate_options()
        values = [o.value for o in opts]
        self.assertIn(1000, values)

    def test_100hz_option_value(self):
        opts = props_mod.get_sampling_rate_options()
        values = [o.value for o in opts]
        self.assertIn(100, values)

    def test_options_are_select_option_instances(self):
        opts = props_mod.get_sampling_rate_options()
        for opt in opts:
            self.assertIsInstance(opt, MockPropertySelectOption)


class TestGetProperties(unittest.TestCase):
    def test_returns_properties_instance(self):
        props = props_mod.get_properties()
        self.assertIsInstance(props, MockProperties)

    def test_mac_address_field_exists(self):
        props = props_mod.get_properties()
        self.assertIn('mac_address', props._fields)

    def test_mac_address_is_text_type(self):
        props = props_mod.get_properties()
        self.assertEqual(props._fields['mac_address']['type'], 'text')

    def test_mac_address_default_is_com10(self):
        props = props_mod.get_properties()
        self.assertEqual(props._defaults['mac_address'], 'COM10')

    def test_sampling_rate_field_exists(self):
        props = props_mod.get_properties()
        self.assertIn('sampling_rate', props._fields)

    def test_sampling_rate_is_select_type(self):
        props = props_mod.get_properties()
        self.assertEqual(props._fields['sampling_rate']['type'], 'select')

    def test_sampling_rate_default_is_1000(self):
        props = props_mod.get_properties()
        self.assertEqual(props._defaults['sampling_rate'], 1000)

    def test_sampling_rate_has_options(self):
        props = props_mod.get_properties()
        opts = props._fields['sampling_rate']['options']
        self.assertGreaterEqual(len(opts), 2)

    def test_two_fields_total(self):
        props = props_mod.get_properties()
        self.assertEqual(len(props._fields), 2)


if __name__ == '__main__':
    unittest.main()
